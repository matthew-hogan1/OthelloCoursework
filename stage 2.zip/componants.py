

# Creates class called BoardSubsection so that when checking if a move is legal the string of colours and also their relative co-ordinates in the board are stored together 
class BoardSubsection():

    # initialises the class, requiring the arguments of values and indices to be passed into the class on instantiation 
    def __init__(self,values,indices):
        self.board_values = values  # the argument values is stored in the attribute self.board_values
        self.board_indices = indices # the argument indices is stored in the attribute self.board_indices

    def get_board_values(self):

        return self.board_values # function to return the value stored in self.board_values
    
    def get_board_indices(self):

        return self.board_indices # function to return the value stored in self.board_indices


def initialise_board(size = 8):
    
    # creates a base list that will hold the rows 
    base_board = []
    
    # Iterates size many times to create that many rows
    for i in range(size):
        
        # creates a list to act as a row 
        row = []
        
        # initialises each column in the row as None 
        for i in range(size):

            row.append('None ')
            

            

        # adds the row into the base board list 
        base_board.append(row)

    
    # sets the middle 4 squares of the board to their respective starting colours
    
    base_board[size//2-1][size//2-1] = 'Light'
    base_board[size//2][size//2] = 'Light'
    base_board[size//2][size//2-1] = 'Dark '
    base_board[size//2-1][size//2] = 'Dark '
    
    # returns the list of lists that represents the board 
    return base_board

def print_board(board):

    # keep track of the rows for labelling
    rowcounter = 1
    
    # print the column number for the user above the rows
    print('    [1]     [2]    [3]    [4]    [5]    [6]    [7]    [8]')
    # iterate over each row in the board
    for row in board:

        rowstring = f'[{rowcounter}] '
        
        # for each cell in the row add contents of the cell to the row string
        
        for cell in row:

            rowstring += f'{cell}  '
        print(rowstring)
        # after each row print a newline character so the next row is printed below the old one 
        print('\n')
        rowcounter += 1

# The function get_subsect_of_board allows the program to get any line of cells starting at a given start co-ordinate and direction

def get_subsect_of_board(row_step,column_step,board,current_row,current_column):

    # list to store the value of the cells in the line as we reach each cell 
    list_of_colours = []

    # list to store the (row,column) of each cell in the line 
    list_of_board_indices = []
    
    # uses len() to check how many rows/columns there is in the board then assigns that value to the variable board_size
    board_size = len(board)

    # The loop will continue as long as both the row and column being checked are within the range of values for the board 
    while (current_row < board_size and current_row >= 0) and (current_column < board_size and current_column >= 0):


        # adds the colour stored in the current cell being checked to the list_of_colours list
        list_of_colours.append(board[current_row][current_column])
        
        # adds the indice of the current row and column in the form (row,column) to the list_of_board_indices list 
        list_of_board_indices.append((current_row,current_column))
        
        # changes the current_row variable by the amount specified in the argument row_step to allow the next cell to be checked
        current_row += row_step
        
        # changes the current_column variable by the amount specified in the argument column_step to allow the next cell to be checked
        current_column += column_step


    # Once the while loop is completed a BoardSubsection object is created and returned by the function 
    return BoardSubsection(list_of_colours,list_of_board_indices)


# legal move is a function to check if at a given point co-ordinates, a legal move would have been played
def legal_move(playercolour,coordinates,board):

    # unpack the row and column from the co-ordinates 
    row = coordinates[0]
    column = coordinates[1]


    # get the contents of the cell from the board 
    position = board[row][column] 

    # if there is already a counter in the cell then it isnt a valid move so return false 
    if position != 'None ':

        return False
    
    else:

        # get the counters in each straight line of the board from where the counter was placed
        north = get_subsect_of_board(-1,0,board,row,column)
        north_east = get_subsect_of_board(-1,1,board,row,column)
        east = get_subsect_of_board(0,1,board,row,column)
        south_east = get_subsect_of_board(1,1,board,row,column)
        south = get_subsect_of_board(1,0,board,row,column)
        south_west = get_subsect_of_board(1,-1,board,row,column)
        west = get_subsect_of_board(0,-1,board,row,column)
        north_west = get_subsect_of_board(-1,-1,board,row,column)

        
    # create a list of all the possible directions the counter could flip other counters 
    list_of_board_subsections = [north,north_east,east,south_east,south,south_west,west,north_west]
    # iterate through the list of subsections 
    for subsection in list_of_board_subsections:


        # get a list of the contents of all the cells in the subsection of the board
        list_of_colours = subsection.get_board_values()
        
        # get a list of the co-ordinates that are being checked 
        list_of_cell_indices = subsection.get_board_indices()
        
        # create a list to store the cells that would need to be flipped 
        list_of_cells_to_convert = []
        
        # iterate through each cell that needs to be checked
        for i,colour in enumerate(list_of_colours):


            # if its the first cell pass as this is the cell the user wants to place the counter in
            if i == 0:

                continue
            
            # if the cell has no counter end the search as this breaks the chain of counters that could be flipped 
            elif colour == 'None ':

                break

            # if the cell contains a counter of the players colour this forms the end of the framing in which the cells between would get flipped 
            elif colour == playercolour:
                
                # if there are no counters between this counter and the counter the player wants to place (the list is empty) that can be flipped its not a valid move 
                if list_of_cells_to_convert == []:

                    break
                
                # if there are counters that would be flipped then its a legal move so true is returned
                else:

                    return True


                    
            # triggers if the cell containes the other persons counter
            else:

                # gets a list of all the counters after the counter being checked 
                remaining_positions_ahead = list_of_colours[i:]

                # if there is a counter of the players colour later in the line that frames the opponants counter then that opponants counters co-ordinates are added to the list of counters that would get flipped 
                if playercolour in remaining_positions_ahead:

                    list_of_cells_to_convert.append(list_of_cell_indices[i])

        

    # if none of the subsections were legal then its an illegal move so False is returned 
    return False
