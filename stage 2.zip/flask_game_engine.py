from flask import Flask, render_template, request, jsonify
import json,os
from componants import *
from game_engine import *

app = Flask(__name__)


board = initialise_board(8)
players = [Player('Dark ', True), Player('Light', True)]
player_turn = 2
move_counter = 60


@app.route('/')
def index():
    return render_template("index.html", game_board=board)


@app.route('/move')
def move():
    global board, player_turn, move_counter, players

    
    column = int(request.args.get('x')) - 1
    row = int(request.args.get('y')) - 1
    

    current_player = players[player_turn % 2]
    currentcolour = current_player.get_colour()

    
    if not legal_move(currentcolour, (row, column), board):
        
        return jsonify({"status": "fail", "message": "Invalid move try again"})


    
    north = get_subsect_of_board(-1,0,board,row,column)
    north_east = get_subsect_of_board(-1,1,board,row,column)
    east = get_subsect_of_board(0,1,board,row,column)
    south_east = get_subsect_of_board(1,1,board,row,column)
    south = get_subsect_of_board(1,0,board,row,column)
    south_west = get_subsect_of_board(1,-1,board,row,column)
    west = get_subsect_of_board(0,-1,board,row,column)
    north_west = get_subsect_of_board(-1,-1,board,row,column)

    list_of_board_subsections = [north,north_east,east,south_east,south,south_west,west,north_west]
    list_of_cells_to_convert = []

    for subsection in list_of_board_subsections:
        
               
        list_of_colours = subsection.get_board_values()
                        
        # get a list of the co-ordinates that are being checked 
        list_of_cell_indices = subsection.get_board_indices()

        

        for i,colour in enumerate(list_of_colours):
            if i == 0:
            
                continue
            if colour == 'None ':
                
                break

            elif colour == currentcolour:
                
                break

            else:

                remaining_positions_ahead = list_of_colours[i:]
                                
                # if there is a counter of the players colour later in the line that frames the opponants counter then that opponants counters co-ordinates are added to the list of counters that would get flipped
                # check if unbroken chain 
                try:
                    
                    noneindex = remaining_positions_ahead.index('None ')
                
                except:

                    noneindex = 9999
                

                # try and get the index of the next cell containing
                try:
                    currentcolourindex = remaining_positions_ahead.index(currentcolour)

                except:
                    currentcolourindex = 10000
                
                
                if currentcolour in remaining_positions_ahead and currentcolourindex < noneindex:
                    list_of_cells_to_convert.append(list_of_cell_indices[i])

    
    if list_of_cells_to_convert == []:
        return jsonify({"status": "fail", "message": "Invalid move try again"})


    # Place piece
    board[row][column] = currentcolour

    for cell in list_of_cells_to_convert:
                        

        changerow = cell[0]
        changecolumn = cell[1]

        
        # set the cell to the colour of the current players counter
        board[changerow][changecolumn] = currentcolour
    

    # Switch turn
    player_turn += 1
    
    move_counter -= 1
    

    if move_counter == 0:
        
        lightcount = 0
        darkcount = 0

        for row in board:

            for cell in row:

                if cell == 'Dark ':
                    darkcount += 1

                elif cell == 'Light':
                    lightcount += 1

        winmessage = ''

        if darkcount > lightcount:

            winmessage = 'Dark wins'

        elif lightcount > darkcount:

            winmessage = 'Light wins'

        else:

            winmessage = 'Its a draw'  
        
        board = initialise_board(8)
        player_turn = 2
        move_counter = 60
        players = [Player('Dark ', True), Player('Light', True)]
        return jsonify({
        "finished":f'The game has finished.\n{winmessage}\nDark counters: {darkcount}\nLight counters: {lightcount}\n',
        "board": board
        })
    
    else:

        currentcolour = players[player_turn % 2].get_colour()
        currentplayer = players[player_turn % 2]
        legal_move_found = False
        
        while legal_move_found == False:
            for row in range(8):

                for column in range(8):
                    
                    # checks if the user could play a legal move by placing a counter on that cell
                    legalmove = legal_move(currentcolour,(row,column),board)
                    # if that would be a legal move break the loop as the player has at least one move they can play 
                    if legalmove:
                        print(f'legal move found for {currentcolour}')
                        legal_move_found = True 
                        
                        break 
                if legal_move_found:
                    break
            
            # if both players are unable to make a legal move set the move counter to 0 to end the game 
            if players[0].can_make_legal_move() == False and players[1].can_make_legal_move() == False:
                
                
                player_turn = 2
                move_counter = 60
                players = [Player('Dark ', True), Player('Light', True)]
                
                lightcount = 0
                darkcount = 0

                for row in board:

                    for cell in row:

                        if cell == 'Dark ':
                            darkcount += 1

                        elif cell == 'Light':
                            lightcount += 1

                winmessage = ''

                if darkcount > lightcount:

                    winmessage = 'Dark wins'

                elif lightcount > darkcount:

                    winmessage = 'Light wins'

                else:

                    winmessage = 'Its a draw' 
                board = initialise_board(8)

                return jsonify({
                    "finished":f"The game has finished.\n{winmessage}\nDark counters: {darkcount}\nLight counters: {lightcount}\n",
                    "board": board,
                    
                })
            # if only one player cant make a move
            elif legal_move_found == False:
                # set the status of the current player to they cant make a move
                print(f'setting {currentcolour} to false')
                currentplayer.set_can_move(False)
                
                # add one to the player_tracker to move onto the next player
                player_turn += 1

                currentcolour = players[player_turn % 2].get_colour()
                currentplayer = players[player_turn % 2]
                
                
        players[0].set_can_move(True)
        players[1].set_can_move(True)

                

        return jsonify({
                "status": "success",
                "board": board,
                "player": players[player_turn % 2].get_colour()
            })




@app.route('/save', methods=['POST'])
def save():
    global board, player_turn, move_counter, players
    

    try:
        savename = request.data.decode()
    
        try:
            
            gamestate = {
                "board": board,
                "player_turn": player_turn,
                "move_counter": move_counter,
                "darkcanmove":players[0].canmove,
                "lightcanmove":players[1].canmove
            }

            with open(f"{savename}.json", "w") as f:
                json.dump(gamestate, f)


            
            return jsonify({"status":"success","message": f"Game saved successfully as {savename}.json!"})
        except:
            return jsonify({"status":"success","message": f"Failed to save game as {savename}.json!"})

    except:
        return jsonify({"status":"success","message": f"Failed to retrieve the filename to save"})
@app.route('/load',methods=['POST'])
def load():
    global board, player_turn, move_counter, players
    

    try:
        savename = request.data.decode()

        try:
            if not os.path.exists(f"{savename}.json"):
                return jsonify({"status": "fail", "message": f"No saved game found called {savename}."})

            
            
            with open(f"{savename}.json", "r") as f:
                gamestate = json.load(f)

            board = gamestate["board"]
            player_turn = gamestate["player_turn"]
            move_counter = gamestate["move_counter"]
            players[0].set_can_move(gamestate['darkcanmove'])
            players[0].set_can_move(gamestate['lightcanmove'])

            return jsonify({
                "status": "success",
                "board": board,
                "player": players[player_turn % 2].get_colour(),
                "message": "Game loaded successfully"
                })

        except:
                return jsonify({"status": "fail", "message": "An error occured when attempting to load the save."})
        
    except:
                return jsonify({"status": "fail", "message": "An error occured when attempting to retrieve the filename to load."})

if __name__ == "__main__":
    app.run(debug=True)