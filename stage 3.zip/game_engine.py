
# imports all the classes and functions from componants.py
from componants import initialise_board,legal_move,print_board,get_subsect_of_board

# creates a class called player to allow 2 players to be created.
class Player():
    """Class to store the colour and move state of the 2 players"""
    # the player class takes 2 arguments the colour of the players pieces
    # and if they can make a legal move or not.
    def __init__(self,colour,canmove):

        self.colour = colour
        self.canmove = canmove

    # method to get the colour of the players counters
    def get_colour(self):
        """Returns counter colour of player"""
        return self.colour

    # method to return if the player can make a legal move
    def can_make_legal_move(self):
        """Returns if the user has a valid move or not on this round """
        return self.canmove
    # method to set the state of canmove to indicate if the player has a legal
    # move available to them
    def set_can_move(self,canmove):
        """Sets teh state of if the player has a valid move available or not"""
        self.canmove = canmove

# function to get the user to input the co-ordinates of the cell the
# user wants to place the counter into.
def cli_coords_input():
    """A function to prompt the user to enter the 
    co-ordinates of the cell they want to place the counter in"""
    valid_row = False
    # loop to get the user to enter the row number until they enter one thats valid
    while valid_row is False:

        # input for user
        row_input = int(input('Enter your row: '))

        # if the user inputted a row thats outside the bounds of the grid tell the user its invalid
        if row_input < 1 or row_input > 8:

            print('Invalid row chosen')

        # if the users input is valid set valid_row to true to end the loop
        else:

            valid_row = True

    valid_column = False
    # loop to get the user to enter the column number until they enter one thats valid
    while valid_column is False:

        column_input = int(input('Enter your column: '))
        # if the user inputted a column thats outside the bounds
        # of the grid tell the user its invalid
        if column_input < 1 or column_input > 8:

            print('Invalid column chosen')

        # if the users input is valid set valid_column to true to end the loop
        else:

            valid_column = True

    # return the row and column input as a tuple
    return (row_input,column_input)


def simple_game_loop():
    """A function to simulate the game being played in the command line"""
    # prints welcome message to tell the player they are the dark counters
    print('Welcome to the game, you are the dark player')

    board_size = 8

    # initialise the board as an 8x8 grid in the form of a 2d array
    board = initialise_board(board_size)

    # sets the number of moves to 60
    move_counter = 60

    # creates a list with 2 instances of the player class.
    # The first is the dark player and the second the light player.
    # Both have the ability to make a legal move as true
    players = [Player('Dark ',True),Player('Light',True)]

    # counter to track which players turn it is.
    player_tracker = 2


    # loops whilst there are still moves left
    while move_counter > 0:

        # takes the player tracker number and takes the modulous with 2.
        # If remainder is 0 its the dark players turn if its 1 its the light players turn.
        currentplayer: Player = players[player_tracker%2]

        # gets the colour of the counter for the current player
        currentcolour = currentplayer.get_colour()

        legal_move_found = False

        # loop through every cell in the board
        while legal_move_found is False:
            for row in range(8):

                for column in range(8):

                    # checks if the user could play a legal move by placing a counter on that cell
                    legalmove = legal_move(currentcolour,(row,column),board)
                    # if that would be a legal move break the loop as
                    # the player has at least one move they can play
                    if legalmove:

                        legal_move_found = True

                        break


            # if both players are unable to make a legal move
            # set the move counter to 0 to end the game
            if players[0].can_make_legal_move() is False and players[1].can_make_legal_move() is False:

                move_counter = 0
                break
            # if only one player cant make a move
            if legal_move_found is False:
                # set the status of the current player to they cant make a move
                currentplayer.set_can_move(False)

                # add one to the player_tracker to move onto the next player
                player_tracker += 1

                # set the current player and colour to the player and colour of the next player
                currentplayer: Player = players[player_tracker%2]
                currentcolour = currentplayer.get_colour()


        # if there are still moves left and someone can make a legal move
        if move_counter != 0:

            # print the number of moves left and which players turn it is
            print(f'moves left: {move_counter}')
            print(f"{currentcolour}'s turn")

            # print the board
            print_board(board)

            legal_move_chosen = False

            # keep looping whilst the player hasent chosen a valid place to place their counter
            while legal_move_chosen is False:

                # call cli_coords_input() to get the row and column the player inputted
                row,column = cli_coords_input()

                # subtract 1 from the row and column as the board list is indexed starting at 0
                row -= 1
                column -= 1

                # check if the user is making a legal move
                legal_move_check = legal_move(currentcolour,(row,column),board)

                # if the move was legal
                if legal_move_check:


                    # get the counters in every direction from the cell
                    north = get_subsect_of_board(-1,0,board,row,column)
                    north_east = get_subsect_of_board(-1,1,board,row,column)
                    east = get_subsect_of_board(0,1,board,row,column)
                    south_east = get_subsect_of_board(1,1,board,row,column)
                    south = get_subsect_of_board(1,0,board,row,column)
                    south_west = get_subsect_of_board(1,-1,board,row,column)
                    west = get_subsect_of_board(0,-1,board,row,column)
                    north_west = get_subsect_of_board(-1,-1,board,row,column)

                    list_of_board_subsections = [north,north_east,east,south_east,south,south_west,west,north_west]

                    # a list that will be used to store the coordinates
                    # of the cells that need to be flipped
                    list_of_cells_to_convert = []
                    for subsection in list_of_board_subsections:

                        # get a list of the contents of all the cells in the subsection of the board
                        list_of_colours = subsection.get_board_values()

                        # get a list of the co-ordinates that are being checked
                        list_of_cell_indices = subsection.get_board_indices()

                        # iterate through each cell that needs to be checked
                        for i,colour in enumerate(list_of_colours):

                            # if its the first cell pass as this is the cell
                            # the user wants to place the counter in
                            if i == 0:

                                continue

                            # if the cell has no counter end the search as this breaks
                            # the chain of counters that could be flipped
                            if colour == 'None ':

                                break

                            # if the cell contains a counter of the players colour this forms
                            # the end of the framing in which the cells between would get flipped
                            if colour == currentcolour:

                                break

                            # if the cell has a counter of the other colour
                            else:
                                # gets a list of all the counters after the counter being checked
                                remaining_positions_ahead = list_of_colours[i:]

                                # try to get the index of the next empty cell,
                                # and if it dosent exist set it to 9999
                                try:

                                    noneindex = remaining_positions_ahead.index('None ')

                                except Exception:

                                    noneindex = 9999

                                # try and get the index of the next cell containing
                                try:
                                    currentcolourindex = remaining_positions_ahead.index(currentcolour)

                                except Exception:
                                    currentcolourindex = 10000


                                # if there is a counter of the players colour later in the line that
                                # frames the opponants counter then that opponants counters
                                # co-ordinates are added to the list of counters that need flipped
                                if currentcolour in remaining_positions_ahead and currentcolourindex < noneindex:
                                    # add that cell to the list of cells to be flipped
                                    list_of_cells_to_convert.append(list_of_cell_indices[i])


                # change the cell that the user placed the counter in to the colour of the player
                    board[row][column] = currentcolour

                    # iterate through list of all the cells that need to be flipped
                    for cell in list_of_cells_to_convert:


                        changerow = cell[0]
                        changecolumn = cell[1]


                        # set the cell to the colour of the current players counter
                        board[changerow][changecolumn] = currentcolour


                    # set legal move to true to end the loop
                    legal_move_chosen = True

                    # decrease the numbers of moves left by 1
                    move_counter -= 1

                    # add one to the player tracker to swap to the next players turn
                    player_tracker += 1


                # if the move the user wants to make is not legal
                else:
                    # print to tell the user its not a legal move
                    print('This is not a legal move')


    # counters to count how many of each counter type there are
    darkcounters = 0
    lightcounters = 0

    # iterate through all the cells on the board
    for row in board:

        for cell in row:

            # if the cell has a dark counter increase the darkcounter by 1
            if cell == 'Dark ':

                darkcounters += 1

            # if the cell has a light counter increase the lightcounter by 1
            elif cell == 'Light':

                lightcounters += 1

    # print the number of each counter are on the board
    print(f'light counters: {lightcounters}')
    print(f'dark counters: {darkcounters}')



    # print out who won, which is which player has the most counters on the board
    if darkcounters > lightcounters:

        print('Dark wins')

    elif darkcounters < lightcounters:

        print('Light wins')

    else:

        print('Its a draw')



if __name__ == "__main__":

    simple_game_loop()
    