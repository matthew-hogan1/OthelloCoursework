
import json
import os
import logging
from flask import Flask, render_template, request, jsonify

from componants import initialise_board,get_subsect_of_board,legal_move
from game_engine import Player


logging.basicConfig(
    level = logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

# initialises the flask app
app = Flask(__name__)

class GameEngine():
    """Class to store the global game state variables"""
    def __init__(self):


        # creates a board of 8x8 dimensions
        self.board = initialise_board(8)

        # create a list with 2 players in it, one dark and one light
        self.players = [Player('Dark ', True), Player('Light', True)]


        self.player_turn = 2
        self.move_counter = 60



engine = GameEngine()

def get_cells_to_convert(row,column,currentcolour,boardtocheck= engine.board):


    """A function to get a list of the cells that would need to have their pieces
    flipped because of a given move."""

    # get the counters in every direction from the cell
    north = get_subsect_of_board(-1,0,boardtocheck,row,column)
    north_east = get_subsect_of_board(-1,1,boardtocheck,row,column)
    east = get_subsect_of_board(0,1,boardtocheck,row,column)
    south_east = get_subsect_of_board(1,1,boardtocheck,row,column)
    south = get_subsect_of_board(1,0,boardtocheck,row,column)
    south_west = get_subsect_of_board(1,-1,boardtocheck,row,column)
    west = get_subsect_of_board(0,-1,boardtocheck,row,column)
    north_west = get_subsect_of_board(-1,-1,boardtocheck,row,column)

    list_of_board_subsections = [north,north_east,east,south_east,south,south_west,west,north_west]

    # a list that will be used to store the coordinates of the cells that need to be flipped
    list_of_cells_to_convert = []


    # Iterate through every direction of the board
    for subsection in list_of_board_subsections:

        # get a list of the contents of all the cells in the subsection of the board
        list_of_colours = subsection.get_board_values()

        # get a list of the co-ordinates that are being checked
        list_of_cell_indices = subsection.get_board_indices()


        # iterate through each cell that needs to be checked
        for i,colour in enumerate(list_of_colours):

            # if its the first cell pass as this is the cell the user wants to place the counter in
            if i == 0:

                continue

            # if the cell has no counter end the search as this breaks
            # the chain of counters that could be flipped
            if colour == 'None ':

                break

            # if the cell contains a counter of the players colour this
            # forms the end of the framing in which the cells between would get flipped
            if colour == currentcolour:

                break

            # if the cell has a counter of the other colour
            # gets a list of all the counters after the counter being checked
            remaining_positions_ahead = list_of_colours[i:]


            # check to see if there is an empty cell in the list of remaining cells,
            # and if there is record the first instance of an empty cell in the chain
            try:

                noneindex = remaining_positions_ahead.index('None ')

            # if there are no empty cells in the chain set the index to 9999
            except Exception:

                noneindex = 9999


            # try and get the index of the next cell containing a counter
            # of the same colour as the one being placed
            try:
                currentcolourindex = remaining_positions_ahead.index(currentcolour)

            # if there isnt a counter of the same colour set the index of it to 10000
            except Exception:

                currentcolourindex = 10000

            # checks that there is a counter of the same colour in the chain
            # to frame the piece, and that its not disconected via an empty cell
            if currentcolour in remaining_positions_ahead and currentcolourindex < noneindex:

                # if the conditions are met add the cell to the list of cells that need converting
                list_of_cells_to_convert.append(list_of_cell_indices[i])


    return list_of_cells_to_convert


def simulate_placement(temporaryboard,currentdepth,colour,maxdepth):

    """A function for the ai player to simulate how the next 3 moves would play out
    if it placed a counter in different cells, allowing it to pick the best move """


    # if the number of recursions is how many moves to look ahead return 0 to stop the recursion
    if currentdepth == maxdepth:
        logger.info('AI move search reached max depth')
        return 0

    score = 0
    
    # set to -9999 for light so first move is always counted sinceit will always be larger than -9999
    if colour == 'Light':
        best = -9999

    # if its the dark players turn set it to 9999 since we want the score to be lowest possible so first dark move will always be lower than 9999
    else:
        
        best = 9999
    # iterate through every cell in the board
    for rowindex,row in enumerate(temporaryboard):

        for columnindex,column in enumerate(row):

            # check if it would be a legal move to put the counter in the cell
            if legal_move(colour, (rowindex, columnindex), temporaryboard):

                # create a new board for the move to be tested on
                # by copying the temporary board supplied.
                # This is so that other moves being checked arent added to the board,
                # which would make it invalid
                newboard = [newrow[:] for newrow in temporaryboard]

                # place the counter in the cell
                newboard[rowindex][columnindex] = colour

                # get a list of the counters that would flip because of that move
                cells_to_flip = get_cells_to_convert(rowindex,columnindex,colour,newboard)

                # iterate through all the counters that need flipping
                for cell in cells_to_flip:

                    changerow = cell[0]
                    changecolumn = cell[1]


                    # set the cell to the colour of the current players counter
                    newboard[changerow][changecolumn] = colour

                # swap colours for the next iteration as it would be the next players turn

                if colour == 'Light':

                    nextcolour = 'Dark '

                else:

                    nextcolour = 'Light'

                # call the function recursively to simulate the next move
                nextscore = simulate_placement(newboard,currentdepth+1,nextcolour,maxdepth)


                try:
                    # if the move being simulated is the ai player
                    if colour == 'Light':

                        # score represents the number of counters gained through
                        # flipping if playing this move
                        score = len(cells_to_flip) + nextscore

                        # compares to current best score and updates if the move is better
                        best = max(best,score)

                    else:
                        # if its dark turn, assume the player will choose the optimal
                        # move of minimising the number of counters the ai can flip
                        score = nextscore - len(cells_to_flip)

                        # sets the human players move to the one that gives the ai the least points
                        best = min(best,score)
                except Exception as e:
                    
                    best = 0
                    logger.error('Could not find best ai move: %s',e)
    # returns the best move to make on that counter placement
    return best

def ai_move(movesleft):

    """A function to evaluate which move the ai should make """

    # a list to store all potentialmoves for evaluation
    potential_moves =  []
    try:

        # enumerate through the current state of the playing board
        for rowindex,row in enumerate(engine.board):

            for columnindex,column in enumerate(row):

                # check if a legal move could be played in the cell.
                if legal_move('Light', (rowindex, columnindex), engine.board):

                    # create a copy of the board so its not altered when simulating moves
                    newboard = [row[:] for row in engine.board]

                    # set the cell on the copy of the board to light
                    newboard[rowindex][columnindex] = 'Light'

                    # get the list of flips from making this move
                    cells_to_flip = get_cells_to_convert(rowindex,columnindex,'Light',newboard)

                    # simulate flipping the cells necessary
                    for cell in cells_to_flip:

                        rowtoflip = cell[0]
                        columntoflip = cell[1]

                        newboard[rowtoflip][columntoflip] = 'Light'

                    # get the number of flips made
                    flipscore = len(cells_to_flip)

                    # get the number of future flips acheieved on the next 2 turns,
                    # assuming the human and ai both choose the optimal move for them
                    score = simulate_placement(newboard,1,'Dark',max(3,movesleft))

                    # add the score from the current move to the score of future moves
                    score += flipscore

                    # add the co-ordinates of the move and the predicted
                    # number of flips gained to potential moves
                    potential_moves.append(((rowindex,columnindex),score))

        # choose the best move by choosing the move
        # with the highest score, and retrieve the co-oedinates
        bestmove = max(potential_moves,key=lambda x: x[1])[0]

        logger.info('AI best move found at %s',bestmove)
        # return the co-ordinates of the best move to make
        return bestmove

    # if the function hits an error i.e no moves are available return (-1,-1)
    except Exception as e:

        logger.exception('Exception in ai move gathering:%s',e)
        return (-1,-1)


# initialise the gui
@app.route('/')
def index():
    """main flask route"""

    return render_template("index.html", game_board=engine.board)


@app.route('/move')
def move():
    """A flask route that allows the user to make a move via the gui and have it
    update the state of the game,aswell as let the ai make its moves  """



    # get the current player and their colour
    currentplayer:Player = engine.players[engine.player_turn % 2]
    currentcolour = currentplayer.get_colour()


    # if the move was made by the human player
    if currentcolour == 'Dark ':

        try:
            # retrieve the column and row of where the user wants to place the counter
            column = int(request.args.get('x')) - 1
            row = int(request.args.get('y')) - 1

        except Exception as e:
            logger.exception('Failed to get x and y for user move: %s',e)
            return jsonify({"status": "fail", "message": "Could not get x and y coordinates"})

        # If the move isnt valid return a failed status and a message
        # for the user telling them its invalid.
        if not legal_move(currentcolour, (row, column), engine.board):
            logger.error('Invalid move for dark at %s,%s',row,column,)
            return jsonify({"status": "fail", "message": "Invalid move try again"})


        # if its a legal move get a list of cells that would be flipped
        list_of_cells_to_convert = get_cells_to_convert(row,column,currentcolour,engine.board)

        logger.info('Dark player has played the move %s,%s',row,column,)
        # Place piece
        engine.board[row][column] = currentcolour

        for cell in list_of_cells_to_convert:


            changerow = cell[0]
            changecolumn = cell[1]


            # set the cell to the colour of the current players counter
            engine.board[changerow][changecolumn] = currentcolour

        # Switch turn
        engine.player_turn += 1
        logger.info('Switching to ai players turn')
        engine.move_counter -= 1

        # get the light player object
        currentplayer = engine.players[engine.player_turn % 2]
        currentcolour = currentplayer.get_colour()

        if engine.move_counter != 0:
            # call the aimove function to get the co-ordinates of the move the ai should make
            move_to_make = ai_move(engine.move_counter)

            # if there is a legal valid move available
            if move_to_make != (-1,-1):


                # get the row and column of the move to make
                airow = move_to_make[0]
                aicolumn = move_to_make[1]

                logger.info('AI player making move %s,%s',airow,aicolumn,)
                # get a list of counters this move flips
                list_of_cells_to_convert = get_cells_to_convert(airow, aicolumn, currentcolour, engine.board)

                # place ai piece
                engine.board[airow][aicolumn] = currentcolour

                # flip all counters that need flipping
                for cell in list_of_cells_to_convert:

                    row = cell[0]
                    column = cell[1]
                    engine.board[row][column] = currentcolour

                # decrease the number of moves left by 1
                engine.move_counter -= 1

            # if there isnt a valid move for the ai to make skip the ai turn
            else:
                
                logger.error('No valid move for ai player to make,skipping turn')
            
            while True:
                
                engine.players[0].set_can_move(False)
                engine.players[1].set_can_move(False)
                
                if engine.move_counter == 0:

                    break           
                


                for indrow,row in enumerate(engine.board):

                    for indcol,column in enumerate(row):

                        if legal_move('Dark ',(indrow,indcol),engine.board):

                            engine.players[0].set_can_move(True)
                            break

                        if legal_move('Light',(indrow,indcol),engine.board):

                            engine.players[1].set_can_move(True)
                            break
                
                
                if engine.players[0].can_make_legal_move():
                    
                    engine.player_turn += 1
                    break

                if not engine.players[0].can_make_legal_move() and engine.players[1].can_make_legal_move():

                    move_to_make = ai_move(engine.move_counter)

                    # if there is a legal valid move available
                    if move_to_make != (-1,-1):


                        # get the row and column of the move to make
                        airow = move_to_make[0]
                        aicolumn = move_to_make[1]

                        logger.info('AI player making move %s,%s',airow,aicolumn,)
                        # get a list of counters this move flips
                        list_of_cells_to_convert = get_cells_to_convert(airow, aicolumn, currentcolour, engine.board)

                        # place ai piece
                        engine.board[airow][aicolumn] = currentcolour

                        # flip all counters that need flipping
                        for cell in list_of_cells_to_convert:

                            row = cell[0]
                            column = cell[1]
                            engine.board[row][column] = currentcolour

                        # decrease the number of moves left by 1
                        engine.move_counter -= 1

                else:

                    logger.info('Neither player can move')
                    logger.info('Game finished due to neither player being able to make a legal move ')
                    
                    lightcount = 0
                    darkcount = 0

                    # for each cell in the board count the number of light and dark counters
                    for row in engine.board:

                        for cell in row:

                            if cell == 'Dark ':
                                darkcount += 1

                            elif cell == 'Light':
                                lightcount += 1

                    winmessage = ''

                    # if there were more dark counters than light dark wins
                    if darkcount > lightcount:

                        winmessage = 'Dark wins'

                    # if there were more light counters than dark light wins
                    elif lightcount > darkcount:

                        winmessage = 'Light wins'

                    # if there were the same number of each its a draw
                    else:

                        winmessage = 'Its a draw'


                    # reset the board and all other global data to the defaults so a new game can be made
                    engine.board = initialise_board(8)
                    engine.player_turn = 2
                    engine.move_counter = 60
                    engine.players = [Player('Dark ', True), Player('Light', True)]
                    
                    # alert the gui the game is finished and provide the new default board
                    return jsonify({
                        "finished":f"The game has finished as there are no legal moves.\n{winmessage}\nDark counters: {darkcount}\nLight counters: {lightcount}\n",
                        "board": engine.board,

            })
                    
                    
                    
            
            

    

    # if the number of moves left = 0
    if engine.move_counter == 0:

        lightcount = 0
        darkcount = 0

        # for each cell in the board count the number of light and dark counters
        for row in engine.board:

            for cell in row:

                if cell == 'Dark ':
                    darkcount += 1

                elif cell == 'Light':
                    lightcount += 1

        winmessage = ''

        # if there were more dark counters than light dark wins
        if darkcount > lightcount:

            winmessage = 'Dark wins'

        # if there were more light counters than dark light wins
        elif lightcount > darkcount:

            winmessage = 'Light wins'

        # if there were the same number of each its a draw
        else:

            winmessage = 'Its a draw'


        # reset the board and all other global data to the defaults so a new game can be made
        engine.board = initialise_board(8)
        engine.player_turn = 2
        engine.move_counter = 60
        engine.players = [Player('Dark ', True), Player('Light', True)]


        logger.info('Game has finished due to the number of moves left hitting 0')
        # alert the gui the game is finished and provide the new default board
        return jsonify({
        "finished":f'The game has finished as the move counter has hit 0.\n{winmessage}\nDark counters: {darkcount}\nLight counters: {lightcount}\n',
        "board": engine.board
        })


    # if there are still moves left


    logger.info('Number of moves left: %s',engine.move_counter)

    
    


    # return success to the gui aswell as the current board state and which players turn it is
    return jsonify({
            "status": "success",
            "board": engine.board,
            "player": engine.players[engine.player_turn % 2].get_colour(),

        })


@app.route('/save', methods=['POST'])
def save():

    """A flask route to save the current game to a json file"""

    try:

        # retrieve the filename the user wants to save the game as from
        # the gui as plain text and decode into ascii
        savename = request.data.decode()


        # attempt to save the state of the game to a json file
        try:

            gamestate = {
                "board": engine.board,
                "player_turn": engine.player_turn,
                "move_counter": engine.move_counter,
                "darkcanmove":engine.players[0].canmove,
                "lightcanmove":engine.players[1].canmove
            }


            with open(f"{savename}.json", "w") as f:
                json.dump(gamestate, f)

            logger.info('Game saved succesfully as %s.json',savename)
            # return a success message if the game state was saved succesfully
            return jsonify({"status":"success","message": f"Game saved successfully as {savename}.json"})

        # if the game couldnt be saved
        except Exception as e:
            logger.exception('Failed to save game as %s.json: %s',savename,e,)
            # return a fail message
            return jsonify({"status":"fail","message": f"Failed to save game as {savename}.json"})

    except Exception as e:

        logger.exception('Failed to retrieve the filename the user entered: %s',e)
        # return a fail message if the filename the user wanted to save as cant be obtained
        return jsonify({"status":"fail","message": "Failed to retrieve the filename to save"})


@app.route('/load',methods=['POST'])
def load():

    """A flask route to load a game that the user has previously saved"""


    # attempt to load the game the user wants
    try:

        # retrieve the filename of the file the user wants to load from the gui as
        # plain text and decode into ascii
        savename = request.data.decode()

        try:

            # if the file does not exist in the same directory as the source code
            if not os.path.exists(f"{savename}.json"):
                logger.error('File %s.json does not exist',savename)
                # return a fail message to alert the user tthe game couldnt be found
                return jsonify({"status": "fail", "message": f"No saved game found called {savename}.json"})

            # if the file does exist open it and extract the data
            with open(f"{savename}.json", "r") as f:
                gamestate = json.load(f)


            # set the board and other gamedata to whats stored in the file
            engine.board = gamestate["board"]
            engine.player_turn = gamestate["player_turn"]
            engine.move_counter = gamestate["move_counter"]
            engine.players[0].set_can_move(gamestate['darkcanmove'])
            engine.players[1].set_can_move(gamestate['lightcanmove'])

            logger.info('Game %s.json succesfully loaded',savename)
            # return a success message, along with the board and which players turn it is
            return jsonify({
                "status": "success",
                "board": engine.board,
                "player": engine.players[engine.player_turn % 2].get_colour(),
                "message": "Game loaded successfully"
                })

        except Exception as e:

            logger.exception('Exception occured when loading save %s.json: %s',savename,e,)
            # if an error occured alert the user
            return jsonify({"status": "fail", "message": "An error occured when attempting to load the save."})

    # triggers if the function couldnt retrieve the filename from the response object
    except Exception as e:
        logger.exception('Failed to retrieve the filename the user entered: %s',e)
        return jsonify({"status": "fail", "message": "An error occured when attempting to retrieve the filename to load."})

if __name__ == "__main__":

    app.run()
